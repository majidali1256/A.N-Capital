# AGENT MEMORY & IDE DEVELOPMENT GUIDELINES

> **CRITICAL MANDATE FOR ANY AI AGENT / DEVELOPER IN THIS WORKSPACE:**
> Always read and adhere strictly to these rules before modifying any code, creating new pages, or updating assets in this codebase.

---

## 1. BRANDING & NAMING CONSTRAINTS (STRICT)
- **Company Name**: **`A.N Resources`** (or uppercase `A.N RESOURCES`).
  - ❌ **NEVER USE `A.N Capital`** or `Alliance Network Capital` in website text, meta tags, titles, form labels, or headers.
  - ✅ Financial terms like "capital appreciation", "capital preservation", "sovereign capital" ARE ALLOWED in body text.
- **Tagline**: `INVEST • TRADE • GROW`
- **Domain**: `alliancenetworkresources.com`
- **Primary Contact Email**: `contact@alliancenetworkresources.com`

---

## 2. FILE STRUCTURE & DIRECTORY MAP
```
/ (Project Root)
├── index.html               # Homepage (Hero, 3D Canvas, Services Overview, CTA Modal)
├── about.html               # Firm Overview & Executive Profile
├── services.html            # 4 Core Investment Divisions
├── process.html             # 5-Phase Investment Methodology with 3D Scroll Stage
├── contact.html             # Contact Form & Advisory Channels
├── contact.php              # PHP Mailer Backend Script
├── site.webmanifest         # PWA Web App Manifest
├── .htaccess                # Apache Clean URL Rewrite Engine
├── MEMORY.md                # Project History & Overview
├── .gemini/
│   └── memory.md            # IDE Memory & Developer Guardrails
└── assets/
    ├── css/
    │   └── style.css        # Shared Luxury Design System & Custom Utilities
    ├── js/
    │   ├── main.js          # Navigation, Sticky Header, Drawer, Form AJAX, Toast Notifications
    │   ├── 3d-engine.js     # Three.js Background Canvas WebGL Engine
    │   ├── scroll-3d-global.js # Motion Animations, Magnetic Buttons, Spotlight Hovers
    │   └── process-scroll-3d.js # 3D Process Page Scroll Stage Animation
    └── img/
        └── logo.png?v=2     # Official Transparent Gold 3D Emblem
```

---

## 3. FRONTEND ARCHITECTURE & STYLING RULES
- **No Heavy Node Frameworks**: This project uses Vanilla HTML5, Vanilla JavaScript (ES6+), and CSS3 with Tailwind CSS (via CDN runtime). Do NOT convert to React, Next.js, or Vite unless explicitly instructed by the user.
- **Design Tokens**:
  - Primary Gold: `#d4af37` (`--color-primary`)
  - Metallic Light Gold: `#f2ca50` (`--color-primary-light`)
  - Dark Obsidian Background: `#111111` (`--color-background`)
  - Glass Surface: `#131313` / `#1a1a1a` (`--color-surface`)
- **Typography**:
  - Headlines & Display: `'Libre Caslon Text', serif`
  - Body & UI: `'Manrope', sans-serif`
- **Logo References**: Always reference logo as `assets/img/logo.png?v=2` (with cache-bust `?v=2`).

---

## 4. CODE MODIFICATION CHECKLIST
Before saving any changes or generating a deployment package:
1. **Active Page Links**: Ensure `.nav-link` and `.mobile-nav-link` on the modified page have the `active` class set correctly.
2. **Form Inputs**: Ensure form fields match `contact.php` parameters (`first_name`, `last_name`, `email`, `phone`, `asset_class`, `mandate_range`, `message`).
3. **Head Metadata**: Every HTML file MUST contain:
   - `<meta property="og:site_name" content="A.N Resources" />`
   - Schema.org JSON-LD `WebSite` block with `"name": "A.N Resources"`
   - `<link rel="manifest" href="site.webmanifest" />`
   - `<link rel="preload" as="image" href="assets/img/logo.png?v=2" />`

---

## 5. DEPLOYMENT BUNDLING INSTRUCTIONS
When zipping the workspace for cPanel deployment:
```bash
rm -f A.N-Resources-Website.zip
zip -r A.N-Resources-Website.zip index.html about.html services.html process.html contact.html contact.php site.webmanifest MEMORY.md assets .htaccess
```
