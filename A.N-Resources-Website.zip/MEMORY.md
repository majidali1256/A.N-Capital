# Project Memory — A.N Resources Digital Platform

## 1. Project Overview & Identity
- **Official Brand Name**: **A.N Resources** (formerly A.N Capital, updated across all platform files).
- **Official Domain**: `alliancenetworkresources.com`
- **Official Contact Email**: `contact@alliancenetworkresources.com`
- **Brand Tagline**: `INVEST • TRADE • GROW`
- **Core Business**: Private Wealth & Institutional Asset Management (Real Estate, Forex & Multi-Asset Trading, Physical Commodities, Sovereign Wealth Preservation).

---

## 2. Technology Stack & Architecture
- **Frontend Core**: Vanilla HTML5, Vanilla JavaScript (ES6+), CSS3 with Tailwind CSS (CDN runtime).
- **3D Graphics Engine**: Three.js WebGL background stage (`assets/js/3d-engine.js` & `assets/js/process-scroll-3d.js`).
- **Interactive UI Suite**: Framer Motion spring physics & mouse spotlight tracking (`assets/js/scroll-3d-global.js`).
- **Backend Mail Handler**: PHP `mail()` backend (`contact.php`) with sanitized input fields and structured email templates.
- **Client Form Engine**: Asynchronous `fetch()` AJAX form submission in `assets/js/main.js` with loading state & toast notification UI (`#toast-notification`).
- **Progressive Web App (PWA)**: Web App Manifest (`site.webmanifest`) for mobile installation & standalone web app support.
- **Server Routing**: Apache `.htaccess` clean URL rewrite engine.

---

## 3. Core Pages Sitemap
1. **`index.html`**: Main landing page with WebGL 3D hero stage, interactive service highlights, and CTA modals.
2. **`about.html`**: Executive advisory profile, firm values, and institutional vision.
3. **`services.html`**: In-depth breakdown of the 4 investment divisions (Real Estate, Forex, Commodities, Wealth Preservation).
4. **`process.html`**: 5-Phase Investment Methodology with interactive scroll-linked 3D step stage.
5. **`contact.html`**: Direct contact page with executive form and corporate location details.

---

## 4. Design Tokens & Visual Aesthetics
- **Theme**: Dark obsidian luxury financial interface.
- **Primary Colors**:
  - Primary Gold: `#d4af37`
  - Metallic Light Gold: `#f2ca50`
  - Background Dark: `#111111`
  - Glass Surface: `#131313` / `#1a1a1a`
- **Typography Pairings**:
  - Display / Serif Headers: `Libre Caslon Text`
  - Body / UI Elements: `Manrope`
- **Logo Asset**: `assets/img/logo.png?v=2` (Clean transparent 3D gold emblem).

---

## 5. Deployment Workflow (GoDaddy cPanel)
1. **Build Archive**: `A.N-Resources-Website.zip` contains all root HTML files, `contact.php`, `site.webmanifest`, `.htaccess`, and the `assets/` directory.
2. **cPanel Upload**: Upload `A.N-Resources-Website.zip` directly to `public_html/`.
3. **Extraction**: Right-click and Extract in GoDaddy cPanel File Manager (overwrite existing files).
4. **Google Search Indexing**: Submit sitemap / domain to Google Search Console to refresh site name indexing.

---

## 6. Configured MCP Servers (Global)
- **Context7** (`@upstash/context7-mcp`): Live documentation lookup.
- **BrowserMCP** (`@browsermcp/mcp`): Real browser session automation.
- **Framelink / Figma MCP** (`figma-developer-mcp`): Figma design to code scaffolding.
- **Shadcn MCP** (`shadcn-ui-mcp-server`): Component patterns & props reference.
- **Framer MCP** (`@framer/agent`): Motion & Framer component integration.
- **Google Stitch MCP**: Rapid UI screen generation.
- **Global Rule**: Configured in `~/.gemini/config/rules/frontend-design-mcp.md`.
